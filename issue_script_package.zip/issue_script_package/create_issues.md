# ...existing code...
### 対象リポジトリ名
yharuki/create_issue_sample

### GitHubへのアクセストークン
github_pat

### Issueグループ

#### グループ1
タイトル:
ST設計 - Layout
ST設計 - Rotation

本文:
```
### 作業内容
- テスト作成タスク

### 概要
- 準備中
### 詳細
- 準備中
### メモ
- 準備中
```

ラベル:
task,v7.1

#### グループ2
タイトル:
ST実施 - Layout
ST実施 - Rotation

本文:
```
### 作業内容
- テスト実施タスク

### 概要
- 準備中
### 詳細
- 準備中
### メモ
- 準備中
```

ラベル:
task,v7.1
